#Code_ClauseInternship_Music-Streaming
This repository contains  Music Streaming it's help to filtering and minimize and maximize the speed of the song like that. 
